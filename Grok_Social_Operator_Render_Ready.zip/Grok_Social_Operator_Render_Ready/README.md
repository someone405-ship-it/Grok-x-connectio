# Grok Social Operator — Render-ready Custom MCP Connector

This package deploys **one remote MCP server** for one **Grok Custom Connector**. You do not need to import a separate Skill or install a separate Grok plugin. Once connected, Grok discovers the tools exposed by this server.

## What it does

- Connects X accounts through OAuth 2.0 Authorization Code with PKCE.
- Supports multiple named X account connections (for example, `primary` and `brand`).
- Creates X text-post drafts and optional single-image drafts.
- Requires an exact approval phrase before publishing a one-off post.
- Creates weekly campaign calendars for a user-specified count, selected days, times, and timezone.
- Shows the whole batch and requires an exact approval phrase before enabling scheduled publishing.
- Runs a background scheduler, persists its queue and encrypted OAuth tokens, pauses/defer posts after X rate limits, and records audit events.
- Includes task plans and persistent workspace notes.

## Important limits — read before deploying

- **X is the only implemented publishing platform.** Instagram, Facebook Pages, LinkedIn, TikTok, YouTube, and Bluesky are not connected in this build.
- Weekly campaigns require an explicit `posts_per_week` value. The local connector ceiling is 12 posts per rolling 7 days, 3 per rolling 24 hours, and at least 180 minutes between posts by default. These are conservative connector-side safety caps, **not** claims about X's official API limits.
- This build schedules weekly campaign batches. It does not provide a general monthly calendar or a one-off “publish at 3:30 PM tomorrow” scheduler.
- Grok prepares the next batch when asked. The server scheduler publishes already-approved posts; it does not invent next week's content by itself.
- One post can contain text and at most one public HTTPS image (JPEG, PNG, WEBP, or GIF, up to 5 MB). Threads, videos, polls, replies, editing/deleting published posts, and analytics are not implemented.
- X API access and media/post creation permissions depend on your X Developer account and current X API access terms. Live OAuth and publication have not been verified with your credentials in this package.
- Use a single Render instance. The SQLite database on the attached persistent disk is not configured for multiple instances.

## Exact deployment steps

### 1. Download and extract this ZIP

Extract `Grok_Social_Operator_Render_Ready.zip` on your computer. Open the extracted `Grok_Social_Operator_Render_Ready` folder. The files you upload to GitHub must be the **contents of this folder**, including `app.py`, `requirements.txt`, and `render.yaml` at the repository root. Do not upload only the ZIP file or leave the project nested one extra folder deep.

### 2. Create a GitHub repository

1. Open https://github.com/new.
2. Repository name: `grok-social-operator` (or another name you prefer).
3. Set it to **Private**; this is recommended.
4. Click **Create repository**.
5. On the empty repository page, choose **uploading an existing file**.
6. Drag in all extracted project files and folders. Confirm `render.yaml` is at the top/root level beside `app.py`.
7. Click **Commit changes**.

Do not upload a real `.env` file, OAuth secret, bearer token, or encryption key. The ZIP contains only `.env.example` with placeholders.

### 3. Create the Render service from the Blueprint

1. Open https://dashboard.render.com/.
2. Click **New** → **Blueprint**.
3. Connect GitHub if asked, then select the `grok-social-operator` repository.
4. Render reads the root `render.yaml`. Check that it shows one Web Service named `grok-social-operator`, paid plan `0.5c-512mb` (0.5 CPU / 512 MB RAM), and a 1 GB disk mounted at `/var/data`.
5. Apply the Blueprint and let the first deploy finish.
6. Open the created Web Service and copy its public URL. It will look like `https://grok-social-operator.onrender.com` (the actual URL shown in your dashboard is authoritative).
7. Open `https://YOUR-ACTUAL-SERVICE-URL/health` in a browser. You should see JSON containing `"ok": true` and `"mcp": "/mcp"`.

**Cost warning:** this Blueprint intentionally uses a paid always-on service and persistent disk so the scheduler and database do not rely on a sleeping free service. Render may charge for compute and disk storage. Check the price shown in your Render dashboard before applying it. Do not change it to Free for scheduled publishing; Free services spin down and do not support persistent disks.

### 4. Create/configure your X Developer App

1. Open https://developer.x.com/en/portal/dashboard.
2. Create or open an X Developer App.
3. Enable **OAuth 2.0** and the **Authorization Code with PKCE** flow.
4. Add this callback URL, replacing the hostname with the exact URL Render gave you:

   `https://YOUR-ACTUAL-SERVICE-URL/oauth/callback`

5. Make sure the app has permissions for reading the authenticated user and creating posts/media. This connector requests these OAuth scopes: `tweet.read tweet.write users.read media.write offline.access`.
6. Copy the OAuth 2.0 **Client ID**. Copy the Client Secret too if your X app/client type provides one.

### 5. Add the X settings to Render

1. In Render, open your Web Service.
2. Click **Environment** → **Add Environment Variable**.
3. Add these exact keys:

   | Key | Value |
   |---|---|
   | `X_CLIENT_ID` | The Client ID from your X Developer App |
   | `X_CLIENT_SECRET` | The Client Secret, if X provides one; otherwise leave blank or omit it |
   | `X_REDIRECT_URI` | `https://YOUR-ACTUAL-SERVICE-URL/oauth/callback` |

4. Do **not** change `MCP_ACCESS_TOKEN` or `TOKEN_ENCRYPTION_KEY` generated by the Blueprint. The encryption key must remain unchanged or previously stored X tokens cannot be decrypted.
5. Click **Save, rebuild, and deploy** (or the equivalent save-and-deploy option).
6. After the redeploy, open `/health` again and confirm `ok` is true.

### 6. Connect the single Custom Connector in Grok

1. Open https://grok.com/connectors.
2. Click **New Connector** → **Custom**.
3. Name it `Grok Social Operator`.
4. MCP server URL:

   `https://YOUR-ACTUAL-SERVICE-URL/mcp`

5. When Grok asks for API-key authentication, use the server's `MCP_ACCESS_TOKEN` value from Render → your service → Environment. The server accepts either of these formats:
   - API-key header: `X-API-Key` with the token as its value.
   - Bearer header: `Authorization: Bearer YOUR_MCP_ACCESS_TOKEN`.
6. Save/connect. Grok should discover tools including `list_platforms`, `start_x_connection`, `create_x_draft`, `create_posting_campaign`, `prepare_campaign_batch`, and `approve_campaign_batch`.

If your Grok screen offers only an OAuth sign-in flow and no API-key/header option, do **not** remove server authentication or make the MCP endpoint public. Stop and share a screenshot of that screen; the authentication choice must match what Grok actually offers.

### 7. Connect your X account through Grok

In a Grok conversation, enter:

> Use the Grok Social Operator connector. Call `list_platforms`, then connect my X account using the label `primary`.

Grok should call `start_x_connection`. Open the returned X authorization URL, sign in to X, and approve the requested access. When the success page appears, return to Grok and ask it to call `list_x_accounts`. Confirm that the expected username appears.

Never paste your X password, Client Secret, `MCP_ACCESS_TOKEN`, or `TOKEN_ENCRYPTION_KEY` into a chat.

### 8. Test with a draft before publishing

Ask Grok:

> Create an X draft that says “Testing my new Grok connector.” Do not publish it. Show me the draft and its approval phrase.

Check the draft. Nothing should publish until you explicitly send the exact phrase returned by the tool. Only approve it if you actually want it posted.

### 9. Create a campaign with your own schedule

Example request (change the count, days, times, timezone, topic, and account to what you actually want):

> Create a weekly X campaign for my game. I want 4 posts per week, on Monday, Wednesday, Friday, and Sunday at 1:00 PM America/New_York. Use the `primary` account. Research current details where necessary, draft four genuinely different posts, and show me the complete calendar. Do not schedule or publish until I review and send the exact campaign approval phrase.

Grok should create the campaign, prepare exactly the requested number of posts, display the full batch/calendar, and wait. After you review it, sending the exact `APPROVE CAMPAIGN ...` phrase enables the scheduled queue. You can later ask Grok to list campaigns, show the calendar, pause/resume a campaign, cancel a queued post, inspect the posting budget, or view the audit log.

## If something fails

- **`/health` does not show `ok: true`:** open Render → service → Logs and check the latest deploy/runtime error.
- **Grok returns 401 Unauthorized:** the API key/header value does not match the exact `MCP_ACCESS_TOKEN` in Render, or Grok is not sending the header you selected. Keep authentication enabled.
- **X OAuth callback error:** verify the callback URL matches character-for-character in the X Developer App and Render's `X_REDIRECT_URI`; verify Client ID and app permissions; redeploy after changing variables.
- **X returns 403/429:** the X app/account may not have endpoint access, or X has rate-limited it. This connector defers/requeues after a 429 reset hint and does not bypass the limit.
- **Scheduled posts do not run while the service sleeps:** confirm you used the paid `0.5c-512mb` plan and that the service is running. Do not remove the disk or scale the SQLite service to multiple instances.

## Official setup references

- Render Web Services: https://render.com/docs/web-services
- Render Blueprints: https://render.com/docs/blueprint-spec
- Render environment variables: https://render.com/docs/configure-environment-variables
- Render persistent disks: https://render.com/docs/disks
- Grok Custom MCP connectors: https://docs.x.ai/grok/connectors
- X OAuth 2.0 with PKCE: https://docs.x.com/fundamentals/authentication/oauth-2-0/authorization-code
- X Create Posts: https://docs.x.com/x-api/posts/create-posts
- X Upload Media: https://docs.x.com/x-api/media/upload-media
