"""Advanced campaign and rate-limit smoke tests; no live X connection is used."""
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from test_smoke import operator


POSTS = [
    {"content": "Five overlooked things that make a Roblox game feel alive: purposeful sound, readable goals, fast feedback, surprising moments, and a reason to return. Which matters most?"},
    {"content": "Building a stronger city-sandbox loop? Give players a short mission, a visible payoff, and one choice that changes their next run."},
    {"content": "Quick design test: remove one UI element from your game. If players understand the feature faster, the interface got better—not just smaller."},
    {"content": "A useful weekly dev habit: record one bug, one player quote, and one improvement after every test session. Evidence beats guessing."},
    {"content": "For villains in a city game, give chaos consequences: rising heat, rival reactions, emergency response, and rewards that change the world."},
    {"content": "Make game updates easier to understand with three details: what changed, why it matters, and how players can try it now."},
    {"content": "Progression should unlock new decisions, not only bigger numbers. Add movement skills, mission choices, or tools that change play style."},
    {"content": "Want players to explore further? Place a useful clue near the map's edge, then reward curiosity with a shortcut or unexpected encounter."},
    {"content": "Reduce frustrating deaths with clear danger signals before damage: readable telegraphs, audio cues, and fair recovery windows."},
    {"content": "Playtest question of the week: where did you hesitate, get lost, or feel powerful? Those moments reveal what deserves improvement."},
]


class AdvancedCampaignTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        operator.DB_PATH = str(Path(self.temp.name) / "advanced.db")

    def tearDown(self):
        self.temp.cleanup()

    def make_campaign(self, posts_per_week=10):
        return json.loads(operator.create_posting_campaign(
            name="Roblox Dev Weekly", topic="Roblox game design and development",
            goal="Share useful, varied game-development ideas", audience="Roblox developers",
            tone="clear, practical, exciting", account_label="primary", posts_per_week=posts_per_week,
            timezone_name="America/New_York", posting_days_json='["mon","tue","wed","thu","fri"]',
            posting_times_json='["09:00","15:00"]', max_posts_per_day=3, min_gap_minutes=180,
        ))

    def test_ten_post_campaign_can_be_prepared_and_batch_approved(self):
        campaign = self.make_campaign()
        self.assertEqual(campaign["posts_per_week"], 10)
        prepared = json.loads(operator.prepare_campaign_batch(campaign["campaign_id"], json.dumps(POSTS)))
        self.assertEqual(prepared["count"], 10)
        self.assertEqual(prepared["status"], "pending_approval")
        self.assertTrue(all(p["scheduled_at"] for p in prepared["posts"]))
        approved = json.loads(operator.approve_campaign_batch(campaign["campaign_id"], prepared["approval_phrase"]))
        self.assertEqual(approved["status"], "active")
        calendar = json.loads(operator.get_campaign_calendar(campaign["campaign_id"]))
        self.assertEqual(len(calendar["posts"]), 10)
        self.assertEqual(sum(1 for p in calendar["posts"] if p["status"] == "queued"), 10)

    def test_posts_above_global_weekly_safety_cap_are_rejected(self):
        with self.assertRaises(ValueError):
            self.make_campaign(posts_per_week=operator.SAFETY_MAX_POSTS_PER_7D + 1)

    def test_near_duplicate_posts_are_rejected(self):
        campaign = self.make_campaign()
        dupes = [{"content": "This is a useful game development tip for creators."},
                 {"content": "This is a useful game development tip for creators!"}] + [
                     {"content": f"Unique post number {i}: consider a different mechanic and test it with players."}
                     for i in range(3, 11)
                 ]
        with self.assertRaises(ValueError):
            operator.prepare_campaign_batch(campaign["campaign_id"], json.dumps(dupes))

    def test_429_records_pause_and_budget_refuses_posting(self):
        class Fake429:
            headers = {"retry-after": "900"}
        blocked_until = operator._record_rate_limit("primary", Fake429())
        self.assertGreater(blocked_until, int(datetime.now(timezone.utc).timestamp()))
        budget = operator._posting_budget("primary")
        self.assertFalse(budget["allowed"])
        self.assertIn("rate-limit", budget["reason"].lower())

    def test_manual_publishing_respects_rolling_local_budget(self):
        with operator._db() as conn:
            now = datetime.now(timezone.utc)
            for i in range(operator.SAFETY_MAX_POSTS_PER_DAY):
                published = (now - timedelta(hours=1 + i)).isoformat(timespec="seconds")
                conn.execute("INSERT INTO drafts(id,platform,account_label,content,status,created_at,published_at) VALUES(?,?,?,?,?,?,?)",
                             (f"OLD{i}", "X", "primary", f"Previously published item {i}", "published", published, published))
            conn.commit()
        budget = operator._posting_budget("primary")
        self.assertFalse(budget["allowed"])
        self.assertEqual(budget["published_last_24h"], operator.SAFETY_MAX_POSTS_PER_DAY)

    def test_audit_log_does_not_expose_tokens(self):
        operator._audit("test_event", "primary", {"note": "example"})
        result = json.loads(operator.get_operator_audit_log(10, "primary"))
        self.assertEqual(result["count"], 1)
        self.assertNotIn("encrypted_tokens", json.dumps(result))

    def test_weighted_length_estimator_handles_urls_and_unicode(self):
        self.assertEqual(operator._x_weighted_length("abc"), 3)
        self.assertEqual(operator._x_weighted_length("https://example.com"), 23)
        self.assertEqual(operator._x_weighted_length("😀"), 2)
        self.assertEqual(operator._x_weighted_length("漢"), 2)

    def test_unicode_copy_is_normalized_for_duplicate_detection(self):
        self.assertEqual(operator._normalize_copy("سلام، دنیا!"), operator._normalize_copy("سلام دنیا"))

    def test_uncertain_publication_must_be_reconciled_before_next_post(self):
        with operator._db() as conn:
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            conn.execute("INSERT INTO drafts(id,platform,account_label,content,status,created_at,last_error) VALUES(?,?,?,?,?,?,?)",
                         ("UNKNOWN1", "X", "primary", "A test draft", "publish_failed_or_unknown", now, "test network failure"))
            conn.commit()
        budget = operator._posting_budget("primary")
        self.assertFalse(budget["allowed"])
        reconciled = json.loads(operator.resolve_uncertain_publication("UNKNOWN1", "not_published"))
        self.assertEqual(reconciled["status"], "draft")
        self.assertTrue(operator._posting_budget("primary")["allowed"])

    def test_scheduler_processes_only_due_approved_posts(self):
        campaign = self.make_campaign()
        prepared = json.loads(operator.prepare_campaign_batch(campaign["campaign_id"], json.dumps(POSTS)))
        operator.approve_campaign_batch(campaign["campaign_id"], prepared["approval_phrase"])
        first = prepared["posts"][0]
        due_time = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(timespec="seconds")
        with operator._db() as conn:
            conn.execute("UPDATE scheduled_posts SET scheduled_at=? WHERE id=?", (due_time, first["scheduled_post_id"]))
            conn.commit()

        def fake_publish(draft_id, scheduled=False):
            self.assertTrue(scheduled)
            with operator._db() as conn:
                now = datetime.now(timezone.utc).isoformat(timespec="seconds")
                conn.execute("UPDATE drafts SET status='published', published_at=? WHERE id=?", (now, draft_id))
                conn.execute("UPDATE scheduled_posts SET status='published', published_at=?, updated_at=? WHERE draft_id=?", (now, now, draft_id))
                conn.commit()
            return json.dumps({"ok": True, "status": "published"})

        with patch.object(operator, "_publish_draft_core", side_effect=fake_publish) as publisher:
            processed = operator._process_due_campaign_posts()
        self.assertEqual(processed, 1)
        publisher.assert_called_once_with(first["draft_id"], scheduled=True)
        calendar = json.loads(operator.get_campaign_calendar(campaign["campaign_id"]))
        self.assertEqual(next(p for p in calendar["posts"] if p["id"] == first["scheduled_post_id"])["status"], "published")


if __name__ == "__main__":
    unittest.main(verbosity=2)
