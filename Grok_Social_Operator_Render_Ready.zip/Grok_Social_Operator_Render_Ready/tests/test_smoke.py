"""Offline smoke tests for core behavior. No live X account or network is needed."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

# The normal install includes mcp[cli]; the test harness replaces only the MCP
# decorator/server shell so these smoke tests can still run offline without it.
try:
    import mcp.server.fastmcp  # noqa: F401
except ImportError:
    import types

    class _FastMCP:
        def __init__(self, *args, **kwargs):
            pass
        def tool(self):
            return lambda func: func
        def custom_route(self, *args, **kwargs):
            return lambda func: func
        def streamable_http_app(self):
            return None

    mcp_module = types.ModuleType("mcp")
    server_module = types.ModuleType("mcp.server")
    fastmcp_module = types.ModuleType("mcp.server.fastmcp")
    fastmcp_module.FastMCP = _FastMCP
    sys.modules.setdefault("mcp", mcp_module)
    sys.modules.setdefault("mcp.server", server_module)
    sys.modules.setdefault("mcp.server.fastmcp", fastmcp_module)

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app as operator  # noqa: E402


class FakeResponse:
    def __init__(self, body):
        self.body = body
    def json(self):
        return self.body


class SocialOperatorSmokeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        operator.DB_PATH = str(Path(self.temp.name) / "smoke.db")

    def tearDown(self):
        self.temp.cleanup()

    def test_db_connection_closes(self):
        with operator._db() as conn:
            conn.execute("SELECT 1")
        with self.assertRaises(Exception):
            conn.execute("SELECT 1")

    def test_account_label_validation(self):
        self.assertEqual(operator._validate_account_label("my-brand_2"), "my-brand_2")
        for bad in ("", "has space", "../x", "x?y", "🔥"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                operator._validate_account_label(bad)

    def test_image_url_rejects_local_and_credentials(self):
        for bad in (
            "http://example.com/img.png",
            "https://localhost/img.png",
            "https://user:pass@example.com/img.png",
            "https://example.com:8443/img.png",
        ):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                operator._validate_public_https_url(bad)

    def test_note_and_task_plan_roundtrip(self):
        saved = json.loads(operator.save_workspace_note("brand-tone", "warm, direct, no fake claims"))
        self.assertTrue(saved["ok"])
        notes = json.loads(operator.read_workspace_notes("brand-tone"))
        self.assertEqual(notes["count"], 1)
        self.assertEqual(notes["notes"][0]["value"], "warm, direct, no fake claims")
        plan = json.loads(operator.save_task_plan("Launch", "Publish a launch campaign", '[{"step":"Draft","status":"planned"}]'))
        listed = json.loads(operator.list_task_plans())
        self.assertEqual(listed["plans"][0]["id"], plan["task_id"])

    def test_gif_uses_gif_media_category(self):
        sent = {}
        def fake_x_request(method, endpoint, label, **kwargs):
            sent.update(kwargs)
            return FakeResponse({"data": {"id": "media-123"}})
        with patch.object(operator, "_download_image", return_value=(b"GIF89a", "image/gif")), patch.object(operator, "_x_request", side_effect=fake_x_request):
            self.assertEqual(operator._upload_x_image("primary", "https://example.com/gif.gif"), "media-123")
        self.assertEqual(sent["json"]["media_category"], "tweet_gif")

    def test_image_only_post_does_not_send_empty_text(self):
        with patch.object(operator, "_validate_public_https_url", side_effect=lambda value: value):
            draft_id = json.loads(operator.create_x_draft(
                content="", image_url="https://example.com/image.png", account_label="primary"
            ))["draft_id"]
        post_payloads = []
        def fake_x_request(method, endpoint, label, **kwargs):
            if endpoint == "/tweets":
                post_payloads.append(kwargs["json"])
                return FakeResponse({"data": {"id": "tweet-123"}})
            return FakeResponse({"data": {}})
        with patch.object(operator, "_validate_public_https_url", side_effect=lambda value: value), \
             patch.object(operator, "_upload_x_image", return_value="media-123"), \
             patch.object(operator, "_x_request", side_effect=fake_x_request):
            result = json.loads(operator.publish_x_draft(draft_id, f"PUBLISH {draft_id}"))
        self.assertEqual(result["status"], "published")
        self.assertNotIn("text", post_payloads[0])
        self.assertEqual(post_payloads[0]["media"]["media_ids"], ["media-123"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
