"""Grok Social Operator MCP server.

Deploy as a remote Streamable HTTP MCP server (for grok.com/connectors).
X is the only implemented publishing platform; campaign scheduling and safety controls are included.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import html
import ipaddress
import json
import os
import re
import secrets
import socket
import sqlite3
import time
import uuid
import difflib
import threading
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta, date
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pathlib import Path
from typing import Any, Iterator
from urllib.parse import urlencode, urlparse

import httpx
from cryptography.fernet import Fernet, InvalidToken
from mcp.server.fastmcp import FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, Response

APP_NAME = "Grok Social Operator Advanced"
_publish_lock = threading.Lock()
DB_PATH = os.getenv("DATABASE_PATH", "./data/social_operator.db")
PORT = int(os.getenv("PORT", "10000"))
MCP_ACCESS_TOKEN = os.getenv("MCP_ACCESS_TOKEN", "")
X_CLIENT_ID = os.getenv("X_CLIENT_ID", "").strip()
X_CLIENT_SECRET = os.getenv("X_CLIENT_SECRET", "").strip()
X_REDIRECT_URI = os.getenv("X_REDIRECT_URI", "").strip()
X_AUTHORIZE_URL = "https://x.com/i/oauth2/authorize"
X_TOKEN_URL = "https://api.x.com/2/oauth2/token"
X_API = "https://api.x.com/2"
X_SCOPES = "tweet.read tweet.write users.read media.write offline.access"
MAX_IMAGE_BYTES = 5 * 1024 * 1024
MAX_POST_CHARS = int(os.getenv("X_MAX_POST_CHARS", "280"))
SAFETY_MAX_POSTS_PER_DAY = int(os.getenv("SAFETY_MAX_POSTS_PER_DAY", "3"))
SAFETY_MAX_POSTS_PER_7D = int(os.getenv("SAFETY_MAX_POSTS_PER_7D", "12"))
SAFETY_MIN_POST_GAP_MINUTES = int(os.getenv("SAFETY_MIN_POST_GAP_MINUTES", "180"))
SCHEDULER_POLL_SECONDS = max(10, int(os.getenv("SCHEDULER_POLL_SECONDS", "30")))

mcp = FastMCP(APP_NAME, instructions=(
    "You are the action layer for a single Grok Custom MCP connection. Use Grok's reasoning and research "
    "abilities to plan, verify facts, and write content; use these tools for persistent notes, drafts, X OAuth, "
    "campaign calendars, approval, scheduling, and publishing. X is the only implemented social platform. "
    "Never claim Instagram, Facebook, LinkedIn, TikTok, YouTube, or Bluesky publishing is connected. "
    "For a one-off post, create and show a draft, then wait for the user's exact PUBLISH phrase before publishing. "
    "For a campaign, ask for or infer the user's requested post count, days, times, and timezone; do not assume "
    "a fixed weekly count. The weekly count is a required input and must be within the connector's local safety "
    "ceiling. Prepare the complete batch, show every post and scheduled time, and wait for the exact APPROVE "
    "CAMPAIGN phrase before activating the queue. Never publish an unapproved draft or batch. "
    "Honor local rolling budgets and X 429/reset hints. Never bypass rate limits or rapidly retry. "
    "If a publishing outcome is uncertain, pause and require reconciliation before retrying to avoid duplicates."
))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def _db() -> Iterator[sqlite3.Connection]:
    """Yield a SQLite connection and always commit/rollback and close it.

    The sqlite3 connection context manager commits transactions but does not close
    the connection. Wrapping it here prevents a connection leak on every tool call.
    """
    path = Path(DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=20000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""CREATE TABLE IF NOT EXISTS oauth_states (
            state TEXT PRIMARY KEY, verifier TEXT NOT NULL, account_label TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS x_accounts (
            label TEXT PRIMARY KEY, encrypted_tokens TEXT NOT NULL, user_id TEXT,
            username TEXT, connected_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS drafts (
            id TEXT PRIMARY KEY, platform TEXT NOT NULL, account_label TEXT NOT NULL,
            content TEXT NOT NULL, image_prompt TEXT NOT NULL DEFAULT '',
            image_url TEXT NOT NULL DEFAULT '', image_alt_text TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL, created_at TEXT NOT NULL, published_at TEXT,
            post_id TEXT, post_url TEXT, last_error TEXT
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS workspace_notes (
            key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS task_plans (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, goal TEXT NOT NULL,
            steps_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS campaigns (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, topic TEXT NOT NULL, goal TEXT NOT NULL,
            audience TEXT NOT NULL, tone TEXT NOT NULL, account_label TEXT NOT NULL,
            platform TEXT NOT NULL, timezone_name TEXT NOT NULL, posts_per_week INTEGER NOT NULL,
            posting_days_json TEXT NOT NULL, posting_times_json TEXT NOT NULL,
            max_posts_per_day INTEGER NOT NULL, min_gap_minutes INTEGER NOT NULL,
            status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            approved_at TEXT, last_error TEXT
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS scheduled_posts (
            id TEXT PRIMARY KEY, campaign_id TEXT NOT NULL, draft_id TEXT NOT NULL UNIQUE,
            scheduled_at TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, published_at TEXT,
            FOREIGN KEY(campaign_id) REFERENCES campaigns(id), FOREIGN KEY(draft_id) REFERENCES drafts(id)
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_scheduled_due ON scheduled_posts(status, scheduled_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_scheduled_campaign ON scheduled_posts(campaign_id, status)")
        conn.execute("""CREATE TABLE IF NOT EXISTS account_safety (
            account_label TEXT PRIMARY KEY, rate_limited_until INTEGER NOT NULL DEFAULT 0,
            last_rate_limit_at TEXT, last_error TEXT
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            account_label TEXT, event_type TEXT NOT NULL, details_json TEXT NOT NULL
        )""")
        conn.commit()
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _fernet() -> Fernet:
    raw = os.getenv("TOKEN_ENCRYPTION_KEY", "").strip().encode()
    if not raw:
        raise RuntimeError(
            "TOKEN_ENCRYPTION_KEY is missing. Set it to a long, random, stable secret in the server environment."
        )
    # Accept either a native Fernet key or a platform-generated random secret.
    # The SHA-256 derivation is deterministic so a generated Render secret can be used
    # directly, while the secret itself never needs to be Fernet-formatted.
    try:
        return Fernet(raw)
    except Exception:
        derived_key = base64.urlsafe_b64encode(hashlib.sha256(raw).digest())
        return Fernet(derived_key)


def _json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, default=str)


def _require_x_config() -> None:
    if not X_CLIENT_ID:
        raise RuntimeError("X_CLIENT_ID is not configured in the server environment.")
    if not X_REDIRECT_URI:
        raise RuntimeError("X_REDIRECT_URI is not configured. It must exactly match the X Developer App callback URL.")
    parsed = urlparse(X_REDIRECT_URI)
    is_https = parsed.scheme == "https" and bool(parsed.hostname)
    is_loopback_test = parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
    if not (is_https or is_loopback_test) or parsed.username or parsed.password or parsed.fragment:
        raise RuntimeError("X_REDIRECT_URI must be a valid HTTPS callback URL (HTTP is allowed only for loopback testing), without embedded credentials or a fragment.")


def _validate_account_label(label: str) -> str:
    label = "primary" if label is None else str(label).strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,39}", label):
        raise ValueError("account_label must be 1–40 characters using letters, numbers, hyphens, or underscores; it must start with a letter or number.")
    return label


def _base64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _save_tokens(label: str, token_data: dict[str, Any], user_id: str, username: str) -> None:
    encrypted = _fernet().encrypt(json.dumps(token_data).encode()).decode()
    with _db() as conn:
        conn.execute(
            "INSERT INTO x_accounts(label, encrypted_tokens, user_id, username, connected_at) "
            "VALUES(?,?,?,?,?) ON CONFLICT(label) DO UPDATE SET encrypted_tokens=excluded.encrypted_tokens, "
            "user_id=excluded.user_id, username=excluded.username, connected_at=excluded.connected_at",
            (label, encrypted, user_id, username, utc_now()),
        )
        conn.commit()


def _refresh_token(label: str, token_data: dict[str, Any]) -> dict[str, Any]:
    refresh = token_data.get("refresh_token")
    if not refresh:
        raise RuntimeError(f"The X access token for '{label}' expired and no refresh token is available. Reconnect that account.")
    _require_x_config()
    form: dict[str, str] = {"grant_type": "refresh_token", "refresh_token": refresh}
    auth = None
    if X_CLIENT_SECRET:
        auth = (X_CLIENT_ID, X_CLIENT_SECRET)
    else:
        form["client_id"] = X_CLIENT_ID
    try:
        response = httpx.post(X_TOKEN_URL, data=form, auth=auth, timeout=30)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        raise RuntimeError(f"X token refresh failed: {exc}") from exc
    fresh = response.json()
    if "access_token" not in fresh:
        raise RuntimeError("X token refresh did not return an access token. Reconnect the X account.")
    merged = dict(token_data)
    merged.update(fresh)
    merged["refresh_token"] = fresh.get("refresh_token") or refresh
    merged["expires_at"] = int(time.time()) + int(fresh.get("expires_in", 7200))
    # Re-save the existing account identity with refreshed encrypted credentials.
    with _db() as conn:
        row = conn.execute("SELECT user_id, username FROM x_accounts WHERE label=?", (label,)).fetchone()
    if not row:
        raise RuntimeError(f"X account '{label}' is not connected.")
    _save_tokens(label, merged, row["user_id"] or "", row["username"] or "")
    return merged


def _get_tokens(label: str) -> dict[str, Any]:
    label = (label or "primary").strip()
    with _db() as conn:
        row = conn.execute("SELECT encrypted_tokens FROM x_accounts WHERE label=?", (label,)).fetchone()
    if not row:
        raise RuntimeError(f"X account '{label}' is not connected. Call start_x_connection first, then visit the authorization URL.")
    try:
        token_data = json.loads(_fernet().decrypt(row["encrypted_tokens"].encode()).decode())
    except InvalidToken as exc:
        raise RuntimeError("Stored X credentials could not be decrypted. Check that TOKEN_ENCRYPTION_KEY has not changed.") from exc
    expires_at = int(token_data.get("expires_at", 0))
    if expires_at and expires_at <= int(time.time()) + 90:
        token_data = _refresh_token(label, token_data)
    return token_data


def _audit(event_type: str, account_label: str | None, details: dict[str, Any]) -> None:
    with _db() as conn:
        conn.execute(
            "INSERT INTO audit_events(created_at, account_label, event_type, details_json) VALUES(?,?,?,?)",
            (utc_now(), account_label, event_type, json.dumps(details, ensure_ascii=False, default=str)),
        )


def _record_rate_limit(label: str, response: httpx.Response) -> int:
    now = int(time.time())
    reset_raw = response.headers.get("x-rate-limit-reset", "") or response.headers.get("RateLimit-Reset", "") or response.headers.get("rate-limit-reset", "")
    retry_raw = response.headers.get("retry-after", "")
    try:
        blocked_until = int(float(reset_raw))
    except (TypeError, ValueError):
        try:
            blocked_until = now + max(60, int(float(retry_raw)))
        except (TypeError, ValueError):
            blocked_until = now + 15 * 60
    # Do not sleep or retry aggressively; pause the account until the provider's reset hint.
    blocked_until = min(max(blocked_until, now + 30), now + 24 * 60 * 60)
    with _db() as conn:
        conn.execute(
            "INSERT INTO account_safety(account_label, rate_limited_until, last_rate_limit_at, last_error) VALUES(?,?,?,?) "
            "ON CONFLICT(account_label) DO UPDATE SET rate_limited_until=MAX(account_safety.rate_limited_until, excluded.rate_limited_until), "
            "last_rate_limit_at=excluded.last_rate_limit_at, last_error=excluded.last_error",
            (label, blocked_until, utc_now(), "X API returned HTTP 429"),
        )
    _audit("rate_limit", label, {"status_code": 429, "blocked_until_epoch": blocked_until})
    return blocked_until


def _posting_budget(label: str) -> dict[str, Any]:
    """Conservative local budget. Counts posts made through this connector, not manual X posts."""
    now = datetime.now(timezone.utc)
    day_cutoff = (now - timedelta(hours=24)).isoformat(timespec="seconds")
    week_cutoff = (now - timedelta(days=7)).isoformat(timespec="seconds")
    with _db() as conn:
        day_rows = conn.execute(
            "SELECT published_at FROM drafts WHERE account_label=? AND platform='X' AND status='published' AND published_at>=? ORDER BY published_at",
            (label, day_cutoff),
        ).fetchall()
        week_rows = conn.execute(
            "SELECT published_at FROM drafts WHERE account_label=? AND platform='X' AND status='published' AND published_at>=? ORDER BY published_at",
            (label, week_cutoff),
        ).fetchall()
        safety = conn.execute("SELECT rate_limited_until FROM account_safety WHERE account_label=?", (label,)).fetchone()
        unknown_count = conn.execute("SELECT COUNT(*) FROM drafts WHERE account_label=? AND status='publish_failed_or_unknown'", (label,)).fetchone()[0]
    published_at_values = [row["published_at"] for row in week_rows if row["published_at"]]
    last_published_dt = None
    if published_at_values:
        try:
            last_published_dt = datetime.fromisoformat(published_at_values[-1])
            if last_published_dt.tzinfo is None:
                last_published_dt = last_published_dt.replace(tzinfo=timezone.utc)
        except ValueError:
            last_published_dt = None
    blocked_until = int(safety["rate_limited_until"]) if safety else 0
    allowed_after: datetime | None = None
    reason = None
    if unknown_count:
        reason = f"There are {unknown_count} unresolved publication result(s) for this account. Reconcile them before publishing again to prevent duplicates."
    elif blocked_until > int(time.time()):
        allowed_after = datetime.fromtimestamp(blocked_until, timezone.utc)
        reason = "X API previously returned a rate-limit response; the account is paused until the provider reset hint."
    elif len(day_rows) >= SAFETY_MAX_POSTS_PER_DAY:
        # Oldest post in the rolling 24-hour window expires at +24 hours.
        try:
            oldest = datetime.fromisoformat(day_rows[0]["published_at"])
            if oldest.tzinfo is None:
                oldest = oldest.replace(tzinfo=timezone.utc)
            allowed_after = oldest + timedelta(hours=24, seconds=5)
        except Exception:
            allowed_after = now + timedelta(hours=24)
        reason = "Connector daily safety budget reached."
    elif len(week_rows) >= SAFETY_MAX_POSTS_PER_7D:
        try:
            oldest = datetime.fromisoformat(week_rows[0]["published_at"])
            if oldest.tzinfo is None:
                oldest = oldest.replace(tzinfo=timezone.utc)
            allowed_after = oldest + timedelta(days=7, seconds=5)
        except Exception:
            allowed_after = now + timedelta(days=7)
        reason = "Connector rolling 7-day safety budget reached."
    elif last_published_dt and (now - last_published_dt) < timedelta(minutes=SAFETY_MIN_POST_GAP_MINUTES):
        allowed_after = last_published_dt + timedelta(minutes=SAFETY_MIN_POST_GAP_MINUTES, seconds=5)
        reason = "Minimum spacing between connector-managed posts has not elapsed."
    allowed = reason is None
    return {
        "allowed": allowed, "reason": reason, "allowed_after": allowed_after.isoformat(timespec="seconds") if allowed_after else None,
        "published_last_24h": len(day_rows), "max_posts_per_24h": SAFETY_MAX_POSTS_PER_DAY,
        "published_last_7d": len(week_rows), "max_posts_per_7d": SAFETY_MAX_POSTS_PER_7D,
        "minimum_gap_minutes": SAFETY_MIN_POST_GAP_MINUTES,
        "unresolved_publication_results": unknown_count,
        "note": "Counts include posts published through this connector; posts made manually on X are not included. X may enforce additional account/app-specific API limits and policies."
    }


def _normalize_copy(value: str) -> str:
    # Keep Unicode letters/numbers so non-English drafts participate in duplicate checks.
    normalized = "".join(ch.casefold() if ch.isalnum() else " " for ch in (value or ""))
    return " ".join(normalized.split())


def _x_weighted_length(text: str) -> int:
    """Conservative approximation of X's weighted text length; URLs count as 23 units."""
    url_pattern = re.compile(r"https?://[^\s]+", re.IGNORECASE)
    ranges_weight_one = ((0x0000, 0x10FF), (0x2000, 0x200D), (0x2010, 0x201F), (0x2032, 0x2037))

    def weight_segment(segment: str) -> int:
        total = 0
        for char in segment:
            codepoint = ord(char)
            total += 1 if any(start <= codepoint <= end for start, end in ranges_weight_one) else 2
        return total

    total = 0
    cursor = 0
    for match in url_pattern.finditer(text or ""):
        raw_url = match.group(0)
        trimmed = raw_url.rstrip(".,!?;:)]}>")
        end = match.start() + len(trimmed)
        total += weight_segment((text or "")[cursor:match.start()])
        total += 23
        total += weight_segment((text or "")[end:match.end()])
        cursor = match.end()
    total += weight_segment((text or "")[cursor:])
    return total


def _check_campaign_copy_batch(posts: list[dict[str, Any]], account_label: str) -> None:
    normalized: list[tuple[int, str]] = []
    for idx, post in enumerate(posts, start=1):
        content = str(post.get("content", "")).strip()
        norm = _normalize_copy(content)
        if not norm:
            continue
        for prior_idx, prior in normalized:
            similarity = difflib.SequenceMatcher(a=norm, b=prior).ratio()
            if norm == prior or similarity >= 0.88:
                raise ValueError(f"Post {idx} is a duplicate or near-duplicate of post {prior_idx} (similarity {similarity:.0%}). Revise it to add genuinely different value.")
        normalized.append((idx, norm))
    # Check recent drafts and published connector posts to avoid recycling the same copy.
    with _db() as conn:
        rows = conn.execute(
            "SELECT content FROM drafts WHERE account_label=? AND platform='X' AND created_at>=? AND content<>'' ORDER BY created_at DESC LIMIT 100",
            (account_label, (datetime.now(timezone.utc) - timedelta(days=30)).isoformat(timespec="seconds")),
        ).fetchall()
    recent = [_normalize_copy(row["content"]) for row in rows]
    for idx, post in enumerate(posts, start=1):
        norm = _normalize_copy(str(post.get("content", "")))
        if not norm:
            continue
        for old in recent:
            if old and difflib.SequenceMatcher(a=norm, b=old).ratio() >= 0.92:
                raise ValueError(f"Post {idx} closely resembles an existing draft/post from the last 30 days. Revise it before scheduling.")


def _parse_json_array(value: str, name: str) -> list[Any]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{name} must be a valid JSON array.") from exc
    if not isinstance(parsed, list):
        raise ValueError(f"{name} must be a JSON array.")
    return parsed


def _get_campaign_week_slots(campaign: sqlite3.Row, week_start: str) -> list[datetime]:
    try:
        start_date = date.fromisoformat(week_start)
    except ValueError as exc:
        raise ValueError("week_start must be an ISO date (YYYY-MM-DD) that falls on a Monday.") from exc
    if start_date.weekday() != 0:
        raise ValueError("week_start must be a Monday to keep weekly calendars predictable.")
    try:
        tz = ZoneInfo(campaign["timezone_name"])
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown timezone '{campaign['timezone_name']}'. Use an IANA timezone such as America/New_York.") from exc
    days = json.loads(campaign["posting_days_json"])
    times = json.loads(campaign["posting_times_json"])
    day_map = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
    slots: list[datetime] = []
    for day in sorted(set(day_map[d] for d in days)):
        for time_text in sorted(set(times)):
            try:
                hh, mm = map(int, time_text.split(":"))
                if not (0 <= hh <= 23 and 0 <= mm <= 59):
                    raise ValueError
            except Exception as exc:
                raise ValueError(f"Invalid posting time '{time_text}'. Use 24-hour HH:MM format.") from exc
            slots.append(datetime.combine(start_date + timedelta(days=day), datetime.min.time(), tzinfo=tz).replace(hour=hh, minute=mm))
    slots.sort()
    for previous, current in zip(slots, slots[1:]):
        if (current.astimezone(timezone.utc) - previous.astimezone(timezone.utc)).total_seconds() < int(campaign["min_gap_minutes"]) * 60:
            raise ValueError("Adjacent posting slots, including across days, violate the configured minimum gap.")
    now = datetime.now(timezone.utc)
    future_slots = [slot for slot in slots if slot.astimezone(timezone.utc) > now + timedelta(minutes=2)]
    per_day: dict[str, int] = {}
    previous_by_day: dict[str, datetime] = {}
    for slot in slots:
        local_date = slot.date().isoformat()
        per_day[local_date] = per_day.get(local_date, 0) + 1
        if local_date in previous_by_day and (slot - previous_by_day[local_date]).total_seconds() < int(campaign["min_gap_minutes"]) * 60:
            raise ValueError(f"Posting times on {local_date} violate the configured minimum gap.")
        previous_by_day[local_date] = slot
    if any(count > int(campaign["max_posts_per_day"]) for count in per_day.values()):
        raise ValueError("The selected posting times exceed this campaign's daily safety cap.")
    return future_slots


def _x_request(method: str, endpoint: str, label: str, **kwargs: Any) -> httpx.Response:
    tokens = _get_tokens(label)
    headers = dict(kwargs.pop("headers", {}))
    headers["Authorization"] = f"Bearer {tokens['access_token']}"
    headers.setdefault("Content-Type", "application/json")
    try:
        response = httpx.request(method, f"{X_API}{endpoint}", headers=headers, timeout=40, **kwargs)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Could not reach the X API: {exc}") from exc
    if response.status_code == 401:
        # A token may have been revoked or invalidated, even if local expiry suggests otherwise.
        raise RuntimeError(f"X rejected the access token for account '{label}'. Reconnect the account and retry.")
    if response.status_code == 429:
        blocked_until = _record_rate_limit(label, response)
        raise RuntimeError(f"X API returned HTTP 429. Publishing is paused until {datetime.fromtimestamp(blocked_until, timezone.utc).isoformat()} according to the provider reset hint. The connector will not bypass this limit.")
    if response.is_error:
        try:
            detail = response.json()
        except Exception:
            detail = response.text[:1000]
        raise RuntimeError(f"X API returned HTTP {response.status_code}: {detail}")
    return response


def _validate_public_https_url(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme != "https" or not parsed.hostname:
        raise ValueError("image_url must be a direct public HTTPS URL.")
    if parsed.username or parsed.password or parsed.fragment:
        raise ValueError("image_url cannot contain embedded credentials or a fragment.")
    if parsed.port not in (None, 443):
        raise ValueError("image_url must use the standard HTTPS port (443).")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain", "metadata.google.internal"} or host.endswith(".local"):
        raise ValueError("Private/local URLs are not allowed for image downloads.")
    try:
        addresses = {ipaddress.ip_address(host)}
    except ValueError:
        try:
            addresses = {ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
        except OSError as exc:
            raise ValueError("Could not resolve the image host.") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ValueError("image_url must resolve only to public IP addresses.")
    return url.strip()


def _download_image(url: str) -> tuple[bytes, str]:
    safe_url = _validate_public_https_url(url)
    try:
        with httpx.Client(follow_redirects=False, timeout=25) as client:
            with client.stream("GET", safe_url, headers={"User-Agent": "GrokSocialOperator/1.0"}) as response:
                if response.is_redirect:
                    raise RuntimeError("The image URL redirects. Provide a direct HTTPS URL that serves the image without a redirect.")
                response.raise_for_status()
                content_type = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                allowed = {"image/jpeg", "image/png", "image/webp", "image/gif"}
                if content_type not in allowed:
                    raise RuntimeError(f"The URL returned '{content_type or 'unknown content type'}', not a supported image. Use JPEG, PNG, WEBP, or GIF.")
                chunks: list[bytes] = []
                total = 0
                for chunk in response.iter_bytes():
                    total += len(chunk)
                    if total > MAX_IMAGE_BYTES:
                        raise RuntimeError("Image exceeds the 5 MB limit for this connector version.")
                    chunks.append(chunk)
                data = b"".join(chunks)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Could not download image: {exc}") from exc
    if not data:
        raise RuntimeError("The image URL returned an empty file.")
    return data, content_type


def _upload_x_image(label: str, image_url: str, alt_text: str = "") -> str:
    image_bytes, mime_type = _download_image(image_url)
    media_category = "tweet_gif" if mime_type == "image/gif" else "tweet_image"
    media_payload = {
        "media": base64.b64encode(image_bytes).decode("ascii"),
        "media_category": media_category,
    }
    upload_response = _x_request("POST", "/media/upload", label, json=media_payload)
    upload_json = upload_response.json()
    media_id = str(upload_json.get("data", {}).get("id", ""))
    if not media_id:
        raise RuntimeError(f"X media upload returned no media ID: {upload_json}")
    if alt_text.strip():
        try:
            _x_request(
                "POST", "/media/metadata", label,
                json={"media_id": media_id, "alt_text": {"text": alt_text.strip()[:1000]}},
            )
        except RuntimeError as exc:
            # Don't silently claim alt text was applied. Stop before publication instead.
            raise RuntimeError(f"The image uploaded, but X did not accept its alt text; the post was not published. Details: {exc}") from exc
    return media_id


@mcp.tool()
def list_platforms() -> str:
    """List social networks this connector can currently publish to."""
    return _json({
        "supported_now": [{"platform": "X", "status": "implemented", "capabilities": ["OAuth connect", "text posts", "one image per post", "drafts", "approval-first weekly campaigns", "scheduled queue", "pause/resume/cancel", "duplicate-copy checks", "rolling local safety budgets", "429 backoff"]}],
        "not_implemented_yet": ["Instagram", "Facebook Pages", "LinkedIn", "TikTok", "YouTube", "Bluesky"],
        "note": "Only X publishing is implemented. Other networks need their own approved API integration and adapter. Scheduled campaigns need an always-on server and durable storage."
    })


@mcp.tool()
def start_x_connection(account_label: str = "primary") -> str:
    """Start secure OAuth connection for one X account label and return the authorization URL to open."""
    _require_x_config()
    if not os.getenv("TOKEN_ENCRYPTION_KEY", "").strip():
        raise RuntimeError("TOKEN_ENCRYPTION_KEY is missing. The server owner must configure it before connecting X.")
    label = _validate_account_label(account_label)
    state = secrets.token_urlsafe(32)
    verifier = _base64url(secrets.token_bytes(48))
    challenge = _base64url(hashlib.sha256(verifier.encode()).digest())
    with _db() as conn:
        conn.execute("DELETE FROM oauth_states WHERE created_at < ?", (int(time.time()) - 900,))
        conn.execute("INSERT INTO oauth_states(state, verifier, account_label, created_at) VALUES(?,?,?,?)",
                     (state, verifier, label, int(time.time())))
        conn.commit()
    params = {
        "response_type": "code", "client_id": X_CLIENT_ID,
        "redirect_uri": X_REDIRECT_URI, "scope": X_SCOPES,
        "state": state, "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    return _json({
        "account_label": label,
        "authorization_url": f"{X_AUTHORIZE_URL}?{urlencode(params)}",
        "instructions": "Open this URL, sign in to the intended X account, and authorize the requested permissions. X will redirect to this connector's callback page when complete. Return to Grok and call list_x_accounts to verify the connection. This URL expires in 15 minutes.",
        "requested_scopes": X_SCOPES.split(),
    })


@mcp.tool()
def list_x_accounts() -> str:
    """List X accounts linked to this server without exposing credentials."""
    with _db() as conn:
        rows = conn.execute("SELECT label, user_id, username, connected_at FROM x_accounts ORDER BY label").fetchall()
    return _json({"connected_accounts": [dict(row) for row in rows], "count": len(rows)})


@mcp.tool()
def disconnect_x_account(account_label: str = "primary") -> str:
    """Remove stored credentials for one X account label. This does not revoke X-side authorization."""
    label = _validate_account_label(account_label)
    with _db() as conn:
        cur = conn.execute("DELETE FROM x_accounts WHERE label=?", (label,))
        conn.commit()
    if not cur.rowcount:
        return _json({"ok": False, "message": f"No connected X account named '{label}'."})
    return _json({"ok": True, "message": f"Stored credentials for '{label}' were removed. To revoke app access at X, also remove the app in X account settings."})


@mcp.tool()
def create_x_draft(
    content: str,
    account_label: str = "primary",
    image_prompt: str = "",
    image_url: str = "",
    image_alt_text: str = "",
) -> str:
    """Save an X post draft. Does not publish. image_url must be a public direct HTTPS image URL."""
    text = (content or "").strip()
    label = _validate_account_label(account_label)
    if not text and not image_url:
        raise ValueError("Provide post text or an image URL.")
    weighted_length = _x_weighted_length(text)
    if weighted_length > MAX_POST_CHARS:
        raise ValueError(f"Post text has an estimated X weighted length of {weighted_length}, over the configured {MAX_POST_CHARS}-unit limit. Shorten it or split it into separate posts. This is a conservative estimate; X remains authoritative.")
    prompt = (image_prompt or "").strip()
    alt_text = (image_alt_text or "").strip()
    if text:
        _check_campaign_copy_batch([{"content": text}], label)
    if len(prompt) > 5000:
        raise ValueError("image_prompt must be no longer than 5,000 characters.")
    if len(alt_text) > 1000:
        raise ValueError("image_alt_text must be no longer than 1,000 characters.")
    if image_url:
        _validate_public_https_url(image_url)
    draft_id = uuid.uuid4().hex[:12].upper()
    with _db() as conn:
        conn.execute(
            "INSERT INTO drafts(id, platform, account_label, content, image_prompt, image_url, image_alt_text, status, created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (draft_id, "X", label, text, prompt, (image_url or "").strip(), alt_text, "draft", utc_now()),
        )
        conn.commit()
    return _json({
        "draft_id": draft_id, "platform": "X", "account_label": label,
        "content": text, "image_prompt": prompt,
        "image_url": (image_url or "").strip(), "image_alt_text": alt_text,
        "status": "draft", "approval_phrase": f"PUBLISH {draft_id}",
        "next_step": "Show the user this exact draft preview and wait. Do not call publish_x_draft unless the user explicitly replies with the exact approval phrase after reviewing the text and image."
    })


@mcp.tool()
def get_x_draft(draft_id: str) -> str:
    """Retrieve a draft and its current publishing status by ID."""
    key = (draft_id or "").strip().upper()
    with _db() as conn:
        row = conn.execute("SELECT * FROM drafts WHERE id=?", (key,)).fetchone()
    if not row:
        return _json({"found": False, "draft_id": key})
    return _json({"found": True, **dict(row), "approval_phrase": f"PUBLISH {key}" if row["status"] == "draft" else None})


def _publish_draft_core(key: str, scheduled: bool = False) -> str:
    """Publish one approved draft. Scheduled jobs are approved only by campaign-batch approval."""
    with _publish_lock:
        with _db() as conn:
            draft_preview = conn.execute("SELECT * FROM drafts WHERE id=?", (key,)).fetchone()
            if not draft_preview:
                raise ValueError(f"Draft '{key}' was not found.")
            if scheduled:
                job = conn.execute("SELECT * FROM scheduled_posts WHERE draft_id=?", (key,)).fetchone()
                if not job or job["status"] != "processing":
                    raise ValueError("Scheduled publication is not in its claimed processing state.")
                if draft_preview["status"] != "scheduled":
                    raise ValueError(f"Scheduled draft '{key}' has status '{draft_preview['status']}' and cannot be published.")
            else:
                if draft_preview["status"] != "draft":
                    raise ValueError(f"Draft '{key}' has status '{draft_preview['status']}' and cannot be published again.")
                linked = conn.execute("SELECT id FROM scheduled_posts WHERE draft_id=?", (key,)).fetchone()
                if linked:
                    raise ValueError("This draft belongs to a campaign. Approve the reviewed campaign batch with approve_campaign_batch; do not publish it individually.")
            row = draft_preview
            label = row["account_label"]
        budget = _posting_budget(label)
        if not budget["allowed"]:
            if scheduled:
                when = budget.get("allowed_after") or (datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(timespec="seconds")
                with _db() as conn:
                    conn.execute("UPDATE scheduled_posts SET status='queued', scheduled_at=?, last_error=?, updated_at=? WHERE draft_id=? AND status='processing'",
                                 (when, budget["reason"], utc_now(), key))
                return _json({"ok": False, "status": "deferred_by_safety_budget", "draft_id": key, "next_attempt_at": when, "budget": budget})
            raise RuntimeError(f"Publishing paused by the local safety budget: {budget['reason']} Earliest safe time: {budget.get('allowed_after')}. Budget: {_json(budget)}")
        with _db() as conn:
            conn.execute("BEGIN IMMEDIATE")
            current = conn.execute("SELECT * FROM drafts WHERE id=?", (key,)).fetchone()
            expected = "scheduled" if scheduled else "draft"
            if not current or current["status"] != expected:
                conn.rollback()
                raise ValueError(f"Draft '{key}' is no longer in the expected '{expected}' state.")
            conn.execute("UPDATE drafts SET status='publishing', last_error=NULL WHERE id=?", (key,))
            conn.commit()
        try:
            payload: dict[str, Any] = {}
            if row["content"]:
                payload["text"] = row["content"]
            if row["image_url"]:
                media_id = _upload_x_image(label, row["image_url"], row["image_alt_text"] or "")
                payload["media"] = {"media_ids": [media_id]}
            result = _x_request("POST", "/tweets", label, json=payload).json()
            post_id = str(result.get("data", {}).get("id", ""))
            if not post_id:
                raise RuntimeError(f"X returned no post ID; publication status is uncertain. Response: {result}")
            with _db() as conn:
                acct = conn.execute("SELECT username FROM x_accounts WHERE label=?", (label,)).fetchone()
                username = (acct["username"] if acct else "") or "i"
                post_url = f"https://x.com/{username}/status/{post_id}"
                conn.execute("UPDATE drafts SET status='published', published_at=?, post_id=?, post_url=?, last_error=NULL WHERE id=?",
                             (utc_now(), post_id, post_url, key))
                if scheduled:
                    conn.execute("UPDATE scheduled_posts SET status='published', published_at=?, last_error=NULL, updated_at=? WHERE draft_id=?",
                                 (utc_now(), utc_now(), key))
                    cid_row = conn.execute("SELECT campaign_id FROM scheduled_posts WHERE draft_id=?", (key,)).fetchone()
                    if cid_row:
                        remaining = conn.execute("SELECT COUNT(*) FROM scheduled_posts WHERE campaign_id=? AND status IN ('queued','pending_approval','processing')", (cid_row["campaign_id"],)).fetchone()[0]
                        if remaining == 0:
                            conn.execute("UPDATE campaigns SET status='completed', updated_at=? WHERE id=?", (utc_now(), cid_row["campaign_id"]))
                conn.commit()
            _audit("published", label, {"draft_id": key, "post_id": post_id, "scheduled": scheduled})
            return _json({"ok": True, "status": "published", "draft_id": key, "account_label": label,
                          "post_id": post_id, "post_url": post_url, "scheduled": scheduled,
                          "message": "X accepted the post."})
        except Exception as exc:
            message = str(exc)
            if "HTTP 429" in message:
                # HTTP 429 is an explicit rejection; safely restore the item to a retryable state.
                with _db() as conn:
                    safety = conn.execute("SELECT rate_limited_until FROM account_safety WHERE account_label=?", (label,)).fetchone()
                    blocked = int(safety["rate_limited_until"]) if safety else int(time.time()) + 900
                    when = datetime.fromtimestamp(max(blocked, int(time.time()) + 30), timezone.utc).isoformat(timespec="seconds")
                    conn.execute("UPDATE drafts SET status=?, last_error=? WHERE id=?",
                                 ("scheduled" if scheduled else "draft", message[:1500], key))
                    if scheduled:
                        conn.execute("UPDATE scheduled_posts SET status='queued', scheduled_at=?, last_error=?, updated_at=? WHERE draft_id=?",
                                     (when, message[:1500], utc_now(), key))
                    conn.commit()
                return _json({"ok": False, "status": "deferred_rate_limit", "draft_id": key,
                              "next_attempt_at": when, "message": "X returned 429. The connector paused and will not try to bypass the limit."})
            with _db() as conn:
                conn.execute("UPDATE drafts SET status='publish_failed_or_unknown', last_error=? WHERE id=?",
                             (message[:1500], key))
                if scheduled:
                    conn.execute("UPDATE scheduled_posts SET status='failed_unknown', last_error=?, updated_at=? WHERE draft_id=?",
                                 (message[:1500], utc_now(), key))
                    conn.execute("UPDATE campaigns SET status='paused', last_error=?, updated_at=? WHERE id=(SELECT campaign_id FROM scheduled_posts WHERE draft_id=?)",
                                 ("Publication result unclear; campaign paused to prevent duplicate posts: " + message[:1000], utc_now(), key))
                conn.commit()
            _audit("publish_failed_or_unknown", label, {"draft_id": key, "error": message[:800], "scheduled": scheduled})
            raise RuntimeError(f"Publishing failed or its result is uncertain: {message}. The draft is marked publish_failed_or_unknown. Check X before any retry to avoid duplicates.") from exc


@mcp.tool()
def publish_x_draft(draft_id: str, approval_phrase: str) -> str:
    """Publish a standalone X draft only after its exact approval phrase is supplied."""
    key = (draft_id or "").strip().upper()
    expected = f"PUBLISH {key}"
    if not hmac.compare_digest((approval_phrase or "").strip(), expected):
        raise ValueError(f"Publishing blocked. Review the draft, then provide the exact phrase: {expected}")
    return _publish_draft_core(key, scheduled=False)


@mcp.tool()
def create_posting_campaign(
    name: str,
    topic: str,
    posts_per_week: int,
    goal: str = "",
    audience: str = "general audience",
    tone: str = "clear, useful, distinctive",
    account_label: str = "primary",
    timezone_name: str = "America/New_York",
    posting_days_json: str = '["mon","tue","wed","thu","fri"]',
    posting_times_json: str = '["09:00","15:00"]',
    max_posts_per_day: int = 3,
    min_gap_minutes: int = 180,
) -> str:
    """Create a recurring X campaign plan. Posts are not generated or published by this tool; prepare and approve each weekly batch separately."""
    title, subject = (name or "").strip(), (topic or "").strip()
    label = _validate_account_label(account_label)
    if not title or len(title) > 120 or not subject or len(subject) > 4000:
        raise ValueError("name is required (max 120 characters) and topic is required (max 4,000 characters).")
    if int(posts_per_week) < 1 or int(posts_per_week) > SAFETY_MAX_POSTS_PER_7D:
        raise ValueError(f"posts_per_week must be between 1 and the configured local safety ceiling of {SAFETY_MAX_POSTS_PER_7D}. This connector schedules weekly campaigns only.")
    if int(max_posts_per_day) < 1 or int(max_posts_per_day) > SAFETY_MAX_POSTS_PER_DAY:
        raise ValueError(f"max_posts_per_day must be between 1 and the global safety ceiling of {SAFETY_MAX_POSTS_PER_DAY}.")
    if int(min_gap_minutes) < SAFETY_MIN_POST_GAP_MINUTES:
        raise ValueError(f"min_gap_minutes cannot be lower than the global safety minimum of {SAFETY_MIN_POST_GAP_MINUTES}.")
    if int(min_gap_minutes) > 24 * 60:
        raise ValueError("min_gap_minutes cannot exceed 1,440 minutes in this weekly-calendar implementation.")
    try:
        ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError("timezone_name must be a valid IANA timezone, for example America/New_York.") from exc
    days = [str(item).lower() for item in _parse_json_array(posting_days_json, "posting_days_json")]
    times = [str(item) for item in _parse_json_array(posting_times_json, "posting_times_json")]
    day_allowed = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"}
    if not days or not set(days).issubset(day_allowed):
        raise ValueError("posting_days_json must contain day codes from mon, tue, wed, thu, fri, sat, sun.")
    if not times:
        raise ValueError("posting_times_json must contain at least one HH:MM time.")
    for time_text in times:
        try:
            hh, mm = map(int, time_text.split(":"))
            if len(time_text) != 5 or not (0 <= hh <= 23 and 0 <= mm <= 59):
                raise ValueError
        except Exception as exc:
            raise ValueError(f"Invalid posting time '{time_text}'. Use 24-hour HH:MM format, e.g. 09:00.") from exc
    if len(set(times)) != len(times):
        raise ValueError("posting_times_json contains duplicate times.")
    if len(set(times)) > int(max_posts_per_day):
        raise ValueError("The number of times per selected day exceeds max_posts_per_day.")
    slots_per_week = len(set(days)) * len(set(times))
    if slots_per_week < int(posts_per_week):
        raise ValueError(f"The selected days and times provide only {slots_per_week} slots/week but campaign requests {posts_per_week} posts/week. Add more time slots.")
    # Same-day planned times must obey the configured minimum gap.
    time_minutes = sorted(int(t[:2]) * 60 + int(t[3:]) for t in times)
    if any(time_minutes[i + 1] - time_minutes[i] < int(min_gap_minutes) for i in range(len(time_minutes) - 1)):
        raise ValueError("Selected posting times are closer than min_gap_minutes.")
    campaign_id = uuid.uuid4().hex[:8].upper()
    now = utc_now()
    with _db() as conn:
        conn.execute("INSERT INTO campaigns(id,name,topic,goal,audience,tone,account_label,platform,timezone_name,posts_per_week,posting_days_json,posting_times_json,max_posts_per_day,min_gap_minutes,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (campaign_id, title, subject, (goal or "").strip(), (audience or "general audience").strip(), (tone or "clear, useful, distinctive").strip(), label, "X", timezone_name, int(posts_per_week), json.dumps(list(dict.fromkeys(days))), json.dumps(sorted(times)), int(max_posts_per_day), int(min_gap_minutes), "setup", now, now))
        conn.commit()
    _audit("campaign_created", label, {"campaign_id": campaign_id, "posts_per_week": int(posts_per_week)})
    return _json({"ok": True, "campaign_id": campaign_id, "name": title, "topic": subject,
                  "posts_per_week": int(posts_per_week), "timezone": timezone_name,
                  "posting_days": list(dict.fromkeys(days)), "posting_times": sorted(times),
                  "daily_safety_cap": int(max_posts_per_day), "weekly_global_safety_cap": SAFETY_MAX_POSTS_PER_7D,
                  "minimum_gap_minutes": int(min_gap_minutes), "status": "setup",
                  "next_step": "Use prepare_campaign_batch with exactly posts_per_week distinct post objects. The full calendar will be shown for approval before any scheduled posts go live."})


@mcp.tool()
def prepare_campaign_batch(campaign_id: str, posts_json: str, week_start: str = "") -> str:
    """Create a complete weekly batch of drafts, check duplicates and safety limits, and propose a calendar. Nothing is published yet."""
    cid = (campaign_id or "").strip().upper()
    posts = _parse_json_array(posts_json, "posts_json")
    with _db() as conn:
        campaign = conn.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
        if not campaign:
            raise ValueError(f"Campaign '{cid}' was not found.")
        if campaign["status"] not in {"setup", "completed", "paused"}:
            raise ValueError(f"Campaign must be in setup/completed/paused state to prepare a new batch; current status is '{campaign['status']}'.")
        outstanding = conn.execute("SELECT COUNT(*) FROM scheduled_posts WHERE campaign_id=? AND status IN ('pending_approval','queued','processing')", (cid,)).fetchone()[0]
        if outstanding:
            raise ValueError("This campaign already has a batch awaiting approval or posting. Review/cancel it before creating another batch.")
    target = int(campaign["posts_per_week"])
    if len(posts) != target:
        raise ValueError(f"Expected exactly {target} post objects, but received {len(posts)}.")
    prepared: list[dict[str, str]] = []
    for idx, raw in enumerate(posts, start=1):
        if not isinstance(raw, dict):
            raise ValueError(f"Post {idx} must be a JSON object.")
        content = str(raw.get("content", "")).strip()
        image_prompt = str(raw.get("image_prompt", "")).strip()
        image_url = str(raw.get("image_url", "")).strip()
        image_alt_text = str(raw.get("image_alt_text", "")).strip()
        if not content and not image_url:
            raise ValueError(f"Post {idx} must contain text or an image URL.")
        weighted_length = _x_weighted_length(content)
        if weighted_length > MAX_POST_CHARS:
            raise ValueError(f"Post {idx} has an estimated X weighted length of {weighted_length}, over the configured {MAX_POST_CHARS}-unit limit.")
        if len(image_prompt) > 5000 or len(image_alt_text) > 1000:
            raise ValueError(f"Post {idx} image prompt must be <= 5,000 characters and alt text <= 1,000 characters.")
        if image_url:
            _validate_public_https_url(image_url)
        prepared.append({"content": content, "image_prompt": image_prompt, "image_url": image_url, "image_alt_text": image_alt_text})
    _check_campaign_copy_batch(prepared, campaign["account_label"])
    if not week_start:
        tz = ZoneInfo(campaign["timezone_name"])
        today = datetime.now(tz).date()
        days_to_next_monday = 7 - today.weekday()
        week_start = (today + timedelta(days=days_to_next_monday)).isoformat()
    slots = _get_campaign_week_slots(campaign, week_start)
    if len(slots) < target:
        raise ValueError(f"Only {len(slots)} future posting slots remain in week starting {week_start}, but the campaign needs {target}. Choose a later Monday.")
    # Spread posts evenly across available configured slots if the slot grid is larger than the target.
    if len(slots) > target:
        selected = [slots[round(i * (len(slots) - 1) / max(1, target - 1))] for i in range(target)]
    else:
        selected = slots
    batch_items = []
    now = utc_now()
    with _db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        latest = conn.execute("SELECT status FROM campaigns WHERE id=?", (cid,)).fetchone()
        if not latest or latest["status"] not in {"setup", "completed", "paused"}:
            conn.rollback()
            raise ValueError("Campaign changed state while preparing. Refresh the campaign and retry.")
        for post, slot in zip(prepared, selected):
            draft_id = uuid.uuid4().hex[:12].upper()
            schedule_id = uuid.uuid4().hex[:10].upper()
            scheduled_utc = slot.astimezone(timezone.utc).isoformat(timespec="seconds")
            conn.execute("INSERT INTO drafts(id,platform,account_label,content,image_prompt,image_url,image_alt_text,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                         (draft_id, "X", campaign["account_label"], post["content"], post["image_prompt"], post["image_url"], post["image_alt_text"], "draft", now))
            conn.execute("INSERT INTO scheduled_posts(id,campaign_id,draft_id,scheduled_at,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                         (schedule_id, cid, draft_id, scheduled_utc, "pending_approval", now, now))
            batch_items.append({"scheduled_post_id": schedule_id, "draft_id": draft_id,
                                "scheduled_at": slot.isoformat(timespec="minutes"), "content": post["content"],
                                "image_prompt": post["image_prompt"], "image_url": post["image_url"],
                                "image_alt_text": post["image_alt_text"]})
        conn.execute("UPDATE campaigns SET status='pending_approval', updated_at=?, last_error=NULL WHERE id=?", (now, cid))
        conn.commit()
    _audit("campaign_batch_prepared", campaign["account_label"], {"campaign_id": cid, "count": len(batch_items), "week_start": week_start})
    return _json({"ok": True, "campaign_id": cid, "campaign_name": campaign["name"], "week_start": week_start,
                  "account_label": campaign["account_label"], "timezone": campaign["timezone_name"],
                  "count": len(batch_items), "status": "pending_approval", "posts": batch_items,
                  "approval_phrase": f"APPROVE CAMPAIGN {cid}",
                  "next_step": "Show every post and scheduled local time to the user. Do not call approve_campaign_batch until the user explicitly approves this exact batch.",
                  "budget_policy": {"max_posts_per_24h": SAFETY_MAX_POSTS_PER_DAY, "max_posts_per_7d": SAFETY_MAX_POSTS_PER_7D, "min_gap_minutes": SAFETY_MIN_POST_GAP_MINUTES}})


@mcp.tool()
def approve_campaign_batch(campaign_id: str, approval_phrase: str) -> str:
    """Approve the exact reviewed weekly batch. The background scheduler will publish only after each due time and safety checks pass."""
    cid = (campaign_id or "").strip().upper()
    expected = f"APPROVE CAMPAIGN {cid}"
    if not hmac.compare_digest((approval_phrase or "").strip(), expected):
        raise ValueError(f"Approval blocked. Review the full campaign calendar and then provide the exact phrase: {expected}")
    with _db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        campaign = conn.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
        if not campaign or campaign["status"] != "pending_approval":
            conn.rollback()
            raise ValueError("Campaign has no batch pending approval. Prepare and review a batch first.")
        rows = conn.execute("SELECT sp.*, d.status AS draft_status FROM scheduled_posts sp JOIN drafts d ON d.id=sp.draft_id WHERE sp.campaign_id=? AND sp.status='pending_approval'", (cid,)).fetchall()
        if len(rows) != int(campaign["posts_per_week"]) or any(row["draft_status"] != "draft" for row in rows):
            conn.rollback()
            raise ValueError("The campaign batch is incomplete or has changed. Regenerate and review it before approval.")
        now = utc_now()
        conn.execute("UPDATE scheduled_posts SET status='queued', updated_at=? WHERE campaign_id=? AND status='pending_approval'", (now, cid))
        conn.execute("UPDATE drafts SET status='scheduled' WHERE id IN (SELECT draft_id FROM scheduled_posts WHERE campaign_id=? AND status='queued')", (cid,))
        conn.execute("UPDATE campaigns SET status='active', approved_at=?, updated_at=?, last_error=NULL WHERE id=?", (now, now, cid))
        conn.commit()
    _audit("campaign_approved", campaign["account_label"], {"campaign_id": cid, "count": len(rows)})
    return _json({"ok": True, "campaign_id": cid, "status": "active", "queued_posts": len(rows),
                  "message": "Batch approved. Posts will be attempted at their scheduled local times only while the campaign is active and safety-budget checks pass.",
                  "important": "The scheduler does not bypass X rate limits. If X returns 429, due posts are deferred by the provider's reset hint; ambiguous publish failures pause the campaign to prevent duplicates."})


@mcp.tool()
def list_posting_campaigns(status: str = "") -> str:
    """List campaigns with queue counts and state."""
    filt = (status or "").strip().lower()
    with _db() as conn:
        if filt:
            campaigns = conn.execute("SELECT * FROM campaigns WHERE status=? ORDER BY created_at DESC LIMIT 100", (filt,)).fetchall()
        else:
            campaigns = conn.execute("SELECT * FROM campaigns ORDER BY created_at DESC LIMIT 100").fetchall()
        output = []
        for campaign in campaigns:
            counts = conn.execute("SELECT status, COUNT(*) AS n FROM scheduled_posts WHERE campaign_id=? GROUP BY status", (campaign["id"],)).fetchall()
            item = dict(campaign)
            item["posting_days"] = json.loads(item.pop("posting_days_json"))
            item["posting_times"] = json.loads(item.pop("posting_times_json"))
            item["queue_counts"] = {r["status"]: r["n"] for r in counts}
            output.append(item)
    return _json({"count": len(output), "campaigns": output})


@mcp.tool()
def get_campaign_calendar(campaign_id: str) -> str:
    """Show every queued, scheduled, published, cancelled, or failed post for a campaign."""
    cid = (campaign_id or "").strip().upper()
    with _db() as conn:
        campaign = conn.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
        if not campaign:
            return _json({"found": False, "campaign_id": cid})
        rows = conn.execute("SELECT sp.*, d.content, d.image_prompt, d.image_url, d.image_alt_text, d.post_url, d.post_id, d.status AS draft_status FROM scheduled_posts sp JOIN drafts d ON d.id=sp.draft_id WHERE sp.campaign_id=? ORDER BY sp.scheduled_at", (cid,)).fetchall()
    zone = ZoneInfo(campaign["timezone_name"])
    posts = []
    for row in rows:
        item = dict(row)
        try:
            scheduled_dt = datetime.fromisoformat(item["scheduled_at"])
            if scheduled_dt.tzinfo is None:
                scheduled_dt = scheduled_dt.replace(tzinfo=timezone.utc)
            item["scheduled_at_local"] = scheduled_dt.astimezone(zone).isoformat(timespec="minutes")
        except Exception:
            item["scheduled_at_local"] = None
        posts.append(item)
    return _json({"found": True, "campaign": {"id": campaign["id"], "name": campaign["name"], "topic": campaign["topic"], "status": campaign["status"], "timezone": campaign["timezone_name"], "account_label": campaign["account_label"]}, "posts": posts})


@mcp.tool()
def pause_posting_campaign(campaign_id: str, reason: str = "Paused by user") -> str:
    """Pause future automatic publication for a campaign without deleting the queue."""
    cid = (campaign_id or "").strip().upper()
    with _db() as conn:
        cur = conn.execute("UPDATE campaigns SET status='paused', last_error=?, updated_at=? WHERE id=? AND status='active'",
                           ((reason or "Paused by user")[:1000], utc_now(), cid))
        conn.commit()
    if not cur.rowcount:
        raise ValueError("Campaign was not found or is already completed/paused.")
    _audit("campaign_paused", None, {"campaign_id": cid, "reason": reason})
    return _json({"ok": True, "campaign_id": cid, "status": "paused", "message": "No queued posts will publish while paused."})


@mcp.tool()
def resume_posting_campaign(campaign_id: str) -> str:
    """Resume a previously paused campaign, subject to the same schedule and budget checks."""
    cid = (campaign_id or "").strip().upper()
    with _db() as conn:
        cur = conn.execute("UPDATE campaigns SET status='active', last_error=NULL, updated_at=? WHERE id=? AND status='paused' AND EXISTS (SELECT 1 FROM scheduled_posts WHERE campaign_id=? AND status='queued')",
                           (utc_now(), cid, cid))
        conn.commit()
    if not cur.rowcount:
        raise ValueError("Campaign has no queued posts to resume, was not found, or was not paused.")
    _audit("campaign_resumed", None, {"campaign_id": cid})
    return _json({"ok": True, "campaign_id": cid, "status": "active"})


@mcp.tool()
def cancel_scheduled_post(scheduled_post_id: str, reason: str = "Cancelled by user") -> str:
    """Cancel one post that has not started publishing. Already published or in-flight posts cannot be cancelled."""
    pid = (scheduled_post_id or "").strip().upper()
    with _db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM scheduled_posts WHERE id=?", (pid,)).fetchone()
        if not row or row["status"] not in {"pending_approval", "queued"}:
            conn.rollback()
            raise ValueError("Scheduled post not found, already started, or already finished.")
        now = utc_now()
        conn.execute("UPDATE scheduled_posts SET status='cancelled', last_error=?, updated_at=? WHERE id=?", ((reason or "Cancelled by user")[:1000], now, pid))
        conn.execute("UPDATE drafts SET status='cancelled', last_error=? WHERE id=?", ((reason or "Cancelled by user")[:1000], row["draft_id"]))
        pending = conn.execute("SELECT COUNT(*) FROM scheduled_posts WHERE campaign_id=? AND status IN ('pending_approval','queued','processing')", (row["campaign_id"],)).fetchone()[0]
        if not pending:
            conn.execute("UPDATE campaigns SET status='completed', updated_at=? WHERE id=?", (now, row["campaign_id"]))
        conn.commit()
    return _json({"ok": True, "scheduled_post_id": pid, "status": "cancelled"})


@mcp.tool()
def get_posting_budget(account_label: str = "primary") -> str:
    """Show connector-managed publishing counts, spacing, and any X rate-limit pause."""
    label = _validate_account_label(account_label)
    budget = _posting_budget(label)
    return _json({"account_label": label, **budget})


@mcp.tool()
def get_operator_audit_log(limit: int = 50, account_label: str = "") -> str:
    """Review recent campaign, publishing, pause, and rate-limit events without exposing credentials."""
    safe_limit = max(1, min(int(limit), 200))
    label = (account_label or "").strip()
    with _db() as conn:
        if label:
            rows = conn.execute("SELECT * FROM audit_events WHERE account_label=? ORDER BY id DESC LIMIT ?", (label, safe_limit)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT ?", (safe_limit,)).fetchall()
    events = []
    for row in rows:
        item = dict(row)
        try:
            item["details"] = json.loads(item.pop("details_json"))
        except Exception:
            item["details"] = {}
        events.append(item)
    return _json({"count": len(events), "events": events})


@mcp.tool()
def resolve_uncertain_publication(draft_id: str, outcome: str, post_id: str = "", post_url: str = "") -> str:
    """Reconcile an ambiguous publication after checking X manually. outcome must be 'published' or 'not_published'."""
    key = (draft_id or "").strip().upper()
    decision = (outcome or "").strip().lower()
    if decision not in {"published", "not_published"}:
        raise ValueError("outcome must be 'published' or 'not_published'.")
    with _db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        draft = conn.execute("SELECT * FROM drafts WHERE id=?", (key,)).fetchone()
        if not draft or draft["status"] != "publish_failed_or_unknown":
            conn.rollback()
            raise ValueError("Draft was not found or does not have an unresolved publication result.")
        scheduled = conn.execute("SELECT * FROM scheduled_posts WHERE draft_id=?", (key,)).fetchone()
        now = utc_now()
        if decision == "published":
            final_id = (post_id or "").strip()
            if not final_id:
                conn.rollback()
                raise ValueError("When outcome='published', supply the actual X post_id after verifying it on X.")
            final_url = (post_url or "").strip()
            if final_url and not (final_url.startswith("https://x.com/") or final_url.startswith("https://twitter.com/")):
                conn.rollback()
                raise ValueError("post_url must be an X URL beginning with https://x.com/ or https://twitter.com/.")
            acct = conn.execute("SELECT username FROM x_accounts WHERE label=?", (draft["account_label"],)).fetchone()
            if not final_url:
                username = (acct["username"] if acct else "") or ""
                if not username:
                    conn.rollback()
                    raise ValueError("Supply the actual post_url because the connected account username is unavailable.")
                final_url = f"https://x.com/{username}/status/{final_id}"
            conn.execute("UPDATE drafts SET status='published', published_at=?, post_id=?, post_url=?, last_error=NULL WHERE id=?",
                         (now, final_id, final_url, key))
            if scheduled:
                conn.execute("UPDATE scheduled_posts SET status='published', published_at=?, last_error=NULL, updated_at=? WHERE draft_id=?", (now, now, key))
                remaining = conn.execute("SELECT COUNT(*) FROM scheduled_posts WHERE campaign_id=? AND status IN ('queued','pending_approval','processing')", (scheduled["campaign_id"],)).fetchone()[0]
                if remaining == 0:
                    conn.execute("UPDATE campaigns SET status='completed', updated_at=?, last_error=NULL WHERE id=?", (now, scheduled["campaign_id"]))
        else:
            new_status = "scheduled" if scheduled else "draft"
            conn.execute("UPDATE drafts SET status=?, last_error=NULL WHERE id=?", (new_status, key))
            if scheduled:
                later = (datetime.now(timezone.utc) + timedelta(minutes=SAFETY_MIN_POST_GAP_MINUTES)).isoformat(timespec="seconds")
                conn.execute("UPDATE scheduled_posts SET status='queued', scheduled_at=?, last_error=NULL, updated_at=? WHERE draft_id=?", (later, now, key))
        conn.commit()
    _audit("uncertain_publication_resolved", draft["account_label"], {"draft_id": key, "outcome": decision, "post_id": post_id})
    return _json({"ok": True, "draft_id": key, "outcome": decision,
                  "status": "published" if decision == "published" else ("queued" if scheduled else "draft"),
                  "next_step": "If this was a campaign post, manually resume the paused campaign after reconciling it." if scheduled else "The standalone draft can now be reviewed and published again if appropriate."})


def _process_due_campaign_posts() -> int:
    """Process due jobs one-by-one; safe to run in more than one app process because jobs are claimed transactionally."""
    now = utc_now()
    with _db() as conn:
        due = conn.execute("SELECT sp.id, sp.campaign_id, sp.draft_id, sp.scheduled_at, c.account_label "
                            "FROM scheduled_posts sp JOIN campaigns c ON c.id=sp.campaign_id "
                            "WHERE sp.status='queued' AND c.status='active' AND sp.scheduled_at<=? "
                            "ORDER BY sp.scheduled_at LIMIT 20", (now,)).fetchall()
    processed = 0
    for item in due:
        budget = _posting_budget(item["account_label"])
        if not budget["allowed"]:
            later = budget.get("allowed_after") or (datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(timespec="seconds")
            with _db() as conn:
                if budget.get("unresolved_publication_results"):
                    conn.execute("UPDATE campaigns SET status='paused', last_error=?, updated_at=? WHERE account_label=? AND status='active'",
                                 (budget["reason"][:1000], utc_now(), item["account_label"]))
                conn.execute("UPDATE scheduled_posts SET scheduled_at=?, last_error=?, updated_at=? WHERE id=? AND status='queued'",
                             (later, budget["reason"], utc_now(), item["id"]))
            continue
        with _db() as conn:
            conn.execute("BEGIN IMMEDIATE")
            changed = conn.execute("UPDATE scheduled_posts SET status='processing', attempts=attempts+1, updated_at=? WHERE id=? AND status='queued'",
                                   (utc_now(), item["id"]))
            conn.commit()
        if not changed.rowcount:
            continue
        try:
            _publish_draft_core(item["draft_id"], scheduled=True)
        except Exception as exc:
            # _publish_draft_core pauses campaigns for ambiguous outcomes; log only, do not auto-retry.
            _audit("scheduler_error", item["account_label"], {"scheduled_post_id": item["id"], "error": str(exc)[:800]})
        processed += 1
    return processed


def _scheduler_loop() -> None:
    while True:
        try:
            _process_due_campaign_posts()
        except Exception as exc:
            # A transient worker error must not take down the MCP API.
            try:
                _audit("scheduler_loop_error", None, {"error": str(exc)[:1000]})
            except Exception:
                pass
        time.sleep(SCHEDULER_POLL_SECONDS)


@mcp.tool()
def save_workspace_note(key: str, value: str) -> str:
    """Save durable project, brand, audience, or campaign instructions for later tasks."""
    note_key = (key or "").strip()
    note_value = (value or "").strip()
    if not note_key or len(note_key) > 120:
        raise ValueError("key must be 1–120 characters.")
    if not note_value or len(note_value) > 20000:
        raise ValueError("value must be 1–20,000 characters.")
    with _db() as conn:
        conn.execute("INSERT INTO workspace_notes(key,value,updated_at) VALUES(?,?,?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                     (note_key, note_value, utc_now()))
        conn.commit()
    return _json({"ok": True, "key": note_key, "updated_at": utc_now()})


@mcp.tool()
def read_workspace_notes(query: str = "") -> str:
    """Read saved brand notes and project context. An empty query returns all notes."""
    q = (query or "").strip().lower()
    with _db() as conn:
        rows = conn.execute("SELECT key,value,updated_at FROM workspace_notes ORDER BY key").fetchall()
    notes = [dict(row) for row in rows if not q or q in row["key"].lower() or q in row["value"].lower()]
    return _json({"count": len(notes), "notes": notes})


@mcp.tool()
def save_task_plan(title: str, goal: str, steps_json: str, status: str = "planned") -> str:
    """Persist a complex-task plan. steps_json must be a JSON array of practical steps."""
    task_title = (title or "").strip()
    task_goal = (goal or "").strip()
    try:
        steps = json.loads(steps_json)
    except json.JSONDecodeError as exc:
        raise ValueError("steps_json must be valid JSON, usually an array of objects with step and status fields.") from exc
    if not isinstance(steps, list) or not steps:
        raise ValueError("steps_json must be a non-empty JSON array.")
    if not task_title or not task_goal:
        raise ValueError("Both title and goal are required.")
    task_id = uuid.uuid4().hex[:8].upper()
    clean_status = status.strip().lower() or "planned"
    with _db() as conn:
        conn.execute("INSERT INTO task_plans(id,title,goal,steps_json,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                     (task_id, task_title, task_goal, json.dumps(steps, ensure_ascii=False), clean_status, utc_now(), utc_now()))
        conn.commit()
    return _json({"ok": True, "task_id": task_id, "title": task_title, "status": clean_status, "steps": steps})


@mcp.tool()
def list_task_plans(status: str = "") -> str:
    """List saved complex-task plans, optionally filtered by status."""
    filter_status = (status or "").strip().lower()
    with _db() as conn:
        if filter_status:
            rows = conn.execute("SELECT * FROM task_plans WHERE status=? ORDER BY updated_at DESC", (filter_status,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM task_plans ORDER BY updated_at DESC LIMIT 100").fetchall()
    plans = []
    for row in rows:
        item = dict(row)
        try:
            item["steps"] = json.loads(item.pop("steps_json"))
        except Exception:
            item["steps"] = []
        plans.append(item)
    return _json({"count": len(plans), "plans": plans})


@mcp.custom_route("/health", methods=["GET"])
async def health(_: Request) -> Response:
    return JSONResponse({"ok": True, "service": APP_NAME, "mcp": "/mcp", "platforms": ["X"], "scheduler": "threaded", "safety_caps": {"max_posts_per_24h": SAFETY_MAX_POSTS_PER_DAY, "max_posts_per_7d": SAFETY_MAX_POSTS_PER_7D, "min_gap_minutes": SAFETY_MIN_POST_GAP_MINUTES}})


@mcp.custom_route("/oauth/callback", methods=["GET"])
async def oauth_callback(request: Request) -> Response:
    """OAuth callback: exchanges X authorization code and stores the encrypted user token."""
    error = request.query_params.get("error")
    code = request.query_params.get("code")
    state = request.query_params.get("state", "")
    if error:
        return HTMLResponse("<h2>X connection was not completed</h2><p>Authorization was declined or failed. Return to Grok and try again.</p>", status_code=400)
    if not code or not state:
        return HTMLResponse("<h2>Invalid X callback</h2><p>The callback did not contain the required authorization code and state.</p>", status_code=400)
    try:
        _require_x_config()
    except Exception as exc:
        safe_error = html.escape(str(exc)[:800])
        return HTMLResponse(
            "<h2>X connection could not be completed</h2>"
            "<p>The server's X OAuth configuration is incomplete. Check the deployment environment variables.</p>"
            f"<pre>{safe_error}</pre>", status_code=500
        )
    with _db() as conn:
        row = conn.execute("SELECT verifier, account_label, created_at FROM oauth_states WHERE state=?", (state,)).fetchone()
        if row:
            conn.execute("DELETE FROM oauth_states WHERE state=?", (state,))
            conn.commit()
    if not row or int(time.time()) - int(row["created_at"]) > 900:
        return HTMLResponse("<h2>Connection link expired</h2><p>Return to Grok and call start_x_connection again.</p>", status_code=400)
    label = row["account_label"]
    form: dict[str, str] = {
        "grant_type": "authorization_code", "code": code,
        "redirect_uri": X_REDIRECT_URI, "code_verifier": row["verifier"],
    }
    auth = None
    if X_CLIENT_SECRET:
        auth = (X_CLIENT_ID, X_CLIENT_SECRET)
    else:
        form["client_id"] = X_CLIENT_ID
    try:
        token_response = httpx.post(X_TOKEN_URL, data=form, auth=auth, timeout=30)
        token_response.raise_for_status()
        tokens = token_response.json()
        if not tokens.get("access_token"):
            raise RuntimeError(f"X token response did not include an access token: {tokens}")
        me_response = httpx.get(f"{X_API}/users/me", headers={"Authorization": f"Bearer {tokens['access_token']}"}, timeout=30)
        me_response.raise_for_status()
        me = me_response.json().get("data", {})
        if not me.get("id") or not me.get("username"):
            raise RuntimeError("X returned no user ID or username.")
        tokens["expires_at"] = int(time.time()) + int(tokens.get("expires_in", 7200))
        _save_tokens(label, tokens, str(me["id"]), str(me["username"]))
        safe_label = html.escape(label)
        safe_user = html.escape(str(me["username"]))
        return HTMLResponse(
            "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>X Connected</title></head>"
            "<body style='font-family:system-ui;max-width:680px;margin:48px auto;padding:0 20px;background:#101114;color:#f3f4f6'>"
            "<h1 style='color:#7dd3fc'>X connected successfully</h1>"
            f"<p>Account <b>@{safe_user}</b> was saved under label <b>{safe_label}</b>.</p>"
            "<p>You can close this page and return to Grok. Ask Grok to run <code>list_x_accounts</code> to verify the connection.</p>"
            "</body></html>", status_code=200)
    except Exception as exc:
        safe_error = html.escape(str(exc)[:1200])
        return HTMLResponse(
            "<!doctype html><html><body style='font-family:system-ui;max-width:680px;margin:48px auto;padding:0 20px'>"
            "<h1>X connection failed</h1><p>Return to Grok and reconnect after checking the X Developer App settings.</p>"
            f"<pre>{safe_error}</pre></body></html>", status_code=500)


class MCPBearerAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if path in {"/health", "/oauth/callback"}:
            return await call_next(request)
        if not MCP_ACCESS_TOKEN:
            return JSONResponse({"error": "MCP_ACCESS_TOKEN is not configured on the server."}, status_code=503)
        authorization = request.headers.get("authorization", "").strip()
        bearer_token = ""
        if authorization.lower().startswith("bearer "):
            bearer_token = authorization[7:].strip()
        api_key = request.headers.get("x-api-key", "").strip()
        configured_token = MCP_ACCESS_TOKEN.strip()
        if not configured_token:
            return JSONResponse({"error": "MCP_ACCESS_TOKEN is not configured on the server."}, status_code=503)
        bearer_ok = bool(bearer_token) and hmac.compare_digest(bearer_token, configured_token)
        api_key_ok = bool(api_key) and hmac.compare_digest(api_key, configured_token)
        if not (bearer_ok or api_key_ok):
            return JSONResponse({"error": "Unauthorized. Configure the connector with the server API key."}, status_code=401)
        return await call_next(request)


def main() -> None:
    # One process keeps the scheduler and MCP API on the same durable database.
    # Deploy on an always-on service for reliable scheduled publication.
    scheduler = threading.Thread(target=_scheduler_loop, name="campaign-scheduler", daemon=True)
    scheduler.start()
    app = mcp.streamable_http_app()
    app.add_middleware(MCPBearerAuthMiddleware)
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level=os.getenv("LOG_LEVEL", "info"))


if __name__ == "__main__":
    main()
